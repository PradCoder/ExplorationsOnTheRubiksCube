Version 2.1.1
=============

The library has been tested using Agda 2.7.0.

* Fixed `Reflection.AST.Definition` to take into account Agda now exposes a `Quantity` argument on the reflection `constructor` constructor.

* In `Reflection.AST.Show` added new function `showQuantity`
