# Development playground

This directory allows you to develop modules against the current dev
version of the stdlib as it currently sits in `src/`.
